import json, sys, math, numpy as np
from PIL import Image

def raster(tris, tex, W, H, light=(0.3, 0.8, -0.5)):
    """tris: list of (verts[3] screen (x,y,depth), uvs[3], shade[3]); returns RGBA image"""
    img = np.zeros((H, W, 4), np.float32); zb = np.full((H, W), 1e9, np.float32)
    th, tw = tex.shape[:2]
    for (p, uv, sh) in tris:
        (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) = p
        minx = max(int(math.floor(min(x0, x1, x2))), 0); maxx = min(int(math.ceil(max(x0, x1, x2))), W - 1)
        miny = max(int(math.floor(min(y0, y1, y2))), 0); maxy = min(int(math.ceil(max(y0, y1, y2))), H - 1)
        if maxx < minx or maxy < miny: continue
        d = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
        if abs(d) < 1e-9: continue
        xs, ys = np.meshgrid(np.arange(minx, maxx + 1) + .5, np.arange(miny, maxy + 1) + .5)
        a = ((y1 - y2) * (xs - x2) + (x2 - x1) * (ys - y2)) / d
        b = ((y2 - y0) * (xs - x2) + (x0 - x2) * (ys - y2)) / d
        c = 1 - a - b
        m = (a >= -1e-4) & (b >= -1e-4) & (c >= -1e-4)
        if not m.any(): continue
        z = a * z0 + b * z1 + c * z2
        u = a * uv[0][0] + b * uv[1][0] + c * uv[2][0]; v = a * uv[0][1] + b * uv[1][1] + c * uv[2][1]
        s = a * sh[0] + b * sh[1] + c * sh[2]
        px = np.clip((u % 1.0) * tw, 0, tw - 1).astype(int); py = np.clip((v % 1.0) * th, 0, th - 1).astype(int)
        col = tex[py, px].astype(np.float32)
        sub_z = zb[miny:maxy + 1, minx:maxx + 1]
        ok = m & (z < sub_z) & (col[..., 3] > 10)
        sub = img[miny:maxy + 1, minx:maxx + 1]
        col[..., :3] *= s[..., None]
        sub[ok] = col[ok]; sub_z[ok] = z[ok]
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), 'RGBA')

def load_obj(path):
    vs, vt, vn, fs = [], [], [], []
    for l in open(path):
        p = l.split()
        if not p: continue
        if p[0] == 'v': vs.append(list(map(float, p[1:4])))
        elif p[0] == 'vt': vt.append(list(map(float, p[1:3])))
        elif p[0] == 'vn': vn.append(list(map(float, p[1:4])))
        elif p[0] == 'f': fs.append([tuple(int(x) for x in t.split('/')) for t in p[1:]])
    return np.array(vs), np.array(vt), np.array(vn), fs

def ball_image(obj, texpath, size=128, yaw=0.0, ss=2):
    vs, vt, vn, fs = load_obj(obj)
    tex = np.array(Image.open(texpath).convert('RGBA'))
    S = size * ss
    cy = 0.404; sc = S * 0.9 / 0.76
    def proj(v):
        x, y, z = v
        x, z = x * math.cos(yaw) + z * math.sin(yaw), -x * math.sin(yaw) + z * math.cos(yaw)
        return (S / 2 - x * sc, S / 2 - (y - cy) * sc, z)
    tris = []
    for f in fs:
        idx = [f[0], f[1], f[2]], ([f[0], f[2], f[3]] if len(f) == 4 else None)
        for t in idx:
            if t is None: continue
            p = [proj(vs[i[0] - 1]) for i in t]
            uv = [(vt[i[1] - 1][0], 1 - vt[i[1] - 1][1]) for i in t]
            sh = []
            for i in t:
                n = vn[i[2] - 1]; sh.append(0.62 + 0.38 * max(0, -n[2] * 0.7 + n[1] * 0.4 + 0.3))
            tris.append((p, uv, sh))
    im = raster(tris, tex, S, S)
    return im.resize((size, size), Image.LANCZOS)

def box_image(modelpath, texpath, size=128, ss=2, rotx=30, roty=35, lids=(0, 0, 0, 0)):
    d = json.load(open(modelpath))['groups']
    tex = np.array(Image.open(texpath).convert('RGBA'))
    S = size * ss
    rx, ry = math.radians(rotx), math.radians(roty)
    sc = S / 36.0
    tris = []
    def xf(pt):
        x, y, z = pt
        x, z = x * math.cos(ry) + z * math.sin(ry), -x * math.sin(ry) + z * math.cos(ry)
        y, z = y * math.cos(rx) - z * math.sin(rx), y * math.sin(rx) + z * math.cos(rx)
        return x, y, z
    def lid(gname, pt):
        x, y, z = pt
        if gname == 'open1': ang, tz = math.radians(-20) * lids[0], -9.5 * lids[0]
        elif gname == 'open2': ang, tz = math.radians(17.5) * lids[0], 9.5 * lids[0]
        else: return pt
        y2 = y * math.cos(ang) - z * math.sin(ang); z2 = y * math.sin(ang) + z * math.cos(ang)
        return x, y2, z2 + tz
    for gname, g in d.items():
        for q in g['quads']:
            pts = [lid(gname, (v[0], v[1], v[2])) for v in q['v']]
            P = []
            for (x, y, z) in pts:
                x, y, z = xf((x, y - 6.5, z))
                P.append((S / 2 - x * sc * -1 * 1 + 0, S / 2 - y * sc, z))
            P = [(S / 2 + (p[0] - S / 2), p[1], p[2]) for p in P]
            uv = [(v[3], v[4]) for v in q['v']]
            n = xf(tuple(q['n'])) if True else None
            sh = 0.6 + 0.4 * max(0, n[1] * 0.8 + n[2] * -0.5 + 0.3)
            for tri in ((0, 1, 2), (0, 2, 3)):
                tris.append(([P[i] for i in tri], [uv[i] for i in tri], [sh] * 3))
    return raster(tris, tex, S, S).resize((size, size), Image.LANCZOS)

if __name__ == '__main__':
    pass
