package com.verity;

import com.verity.entity.VerityBallEntity;
import com.verity.entity.VerityBoxEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class VerityEntities {
    public static final EntityType<VerityBoxEntity> BOX = Registry.register(
            Registries.ENTITY_TYPE, VerityMod.id("verity_box"),
            FabricEntityTypeBuilder.<VerityBoxEntity>create(SpawnGroup.MISC, VerityBoxEntity::new)
                    .dimensions(EntityDimensions.fixed(1.3f, 0.9f))
                    .trackRangeBlocks(64)
                    .trackedUpdateRate(1)
                    .fireImmune()
                    .build());

    public static final EntityType<VerityBallEntity> BALL = Registry.register(
            Registries.ENTITY_TYPE, VerityMod.id("verity_ball"),
            FabricEntityTypeBuilder.<VerityBallEntity>create(SpawnGroup.MISC, VerityBallEntity::new)
                    .dimensions(EntityDimensions.fixed(0.8f, 0.8f))
                    .trackRangeBlocks(64)
                    .trackedUpdateRate(1)
                    .forceTrackedVelocityUpdates(true)
                    .fireImmune()
                    .build());

    public static void register() {
        // Tocar la clase ya registra los campos estaticos.
    }
}
