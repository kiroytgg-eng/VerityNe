package com.verity.entity;

import com.verity.VerityItems;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;

/** La bola Verity: sale de la caja, cae, rebota 4 veces, saluda y se queda de asistente. */
public class VerityBallEntity extends Entity {
    public static final int STATE_HELD = 0;     // asomando dentro de la caja
    public static final int STATE_FALLING = 1;  // cayendo / rebotando
    public static final int STATE_IDLE = 2;     // quieta, esperando

    public static final int BOUNCES = 4;        // golpes contra el piso
    private static final double GRAVITY = 0.07;
    private static final double RESTITUTION = 0.62;

    private static final TrackedData<Integer> STATE =
            DataTracker.registerData(VerityBallEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> IMPACT_SEQ =
            DataTracker.registerData(VerityBallEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> GREET_SEQ =
            DataTracker.registerData(VerityBallEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Optional<UUID>> OWNER =
            DataTracker.registerData(VerityBallEntity.class, TrackedDataHandlerRegistry.OPTIONAL_UUID);

    // Los engancha el cliente (asi esta clase no toca codigo de cliente).
    public static Consumer<VerityBallEntity> CLIENT_TALK = e -> {};
    public static Consumer<VerityBallEntity> CLIENT_GREET = e -> {};

    // servidor
    private int impacts;
    private boolean greetOnLand = true;
    private int greetDelay = -1;

    // cliente
    public int clientImpactAge = -1000;
    private int lastImpactSeq = -1;
    private int lastGreetSeq = -1;

    public VerityBallEntity(EntityType<?> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker() {
        this.dataTracker.startTracking(STATE, STATE_FALLING);
        this.dataTracker.startTracking(IMPACT_SEQ, 0);
        this.dataTracker.startTracking(GREET_SEQ, 0);
        this.dataTracker.startTracking(OWNER, Optional.empty());
    }

    public int getBallState() {
        return this.dataTracker.get(STATE);
    }

    public void setBallState(int s) {
        this.dataTracker.set(STATE, s);
    }

    public UUID getOwnerUuid() {
        return this.dataTracker.get(OWNER).orElse(null);
    }

    public void setOwnerUuid(UUID uuid) {
        this.dataTracker.set(OWNER, Optional.ofNullable(uuid));
    }

    /** La bola nace dentro de la caja: espera quieta y saluda al aterrizar. */
    public void configureFromBox() {
        setBallState(STATE_HELD);
        this.impacts = 0;
        this.greetOnLand = true;
    }

    /** La bola viene del item Verity™: un saltito y listo, sin saludo. */
    public void configureAsPlaced() {
        setBallState(STATE_FALLING);
        this.impacts = BOUNCES - 2;
        this.greetOnLand = false;
    }

    /** La caja suelta la bola. */
    public void release() {
        setVelocity(Vec3d.ZERO);
        setBallState(STATE_FALLING);
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient) {
            clientTick();
        } else {
            serverTick();
        }
    }

    private void serverTick() {
        int state = getBallState();
        if (state == STATE_HELD) {
            setVelocity(Vec3d.ZERO);
            if (this.age > 400) release(); // la caja desaparecio, que no se quede flotando
            return;
        }

        double vy = (getVelocity().y - GRAVITY) * 0.98;
        setVelocity(0.0, vy, 0.0);
        move(MovementType.SELF, getVelocity());
        boolean landed = (this.verticalCollision || this.isOnGround()) && vy < 0;

        if (state == STATE_FALLING) {
            if (landed) {
                if (vy < -0.1) {
                    onImpact(vy);
                } else {
                    this.impacts = BOUNCES;
                    setVelocity(Vec3d.ZERO);
                    setBallState(STATE_IDLE);
                }
            }
        } else if (landed) {
            setVelocity(Vec3d.ZERO);
        }

        if (this.greetDelay >= 0) {
            this.greetDelay--;
            if (this.greetDelay < 0) {
                this.dataTracker.set(GREET_SEQ, this.dataTracker.get(GREET_SEQ) + 1);
            }
        }
    }

    private void onImpact(double vy) {
        this.impacts++;
        this.dataTracker.set(IMPACT_SEQ, this.dataTracker.get(IMPACT_SEQ) + 1);
        getWorld().playSound(null, getX(), getY(), getZ(), SoundEvents.ENTITY_SLIME_SQUISH_SMALL,
                SoundCategory.NEUTRAL, 0.9f, 0.8f + 0.12f * this.impacts);
        if (this.impacts >= BOUNCES) {
            setVelocity(Vec3d.ZERO);
            setBallState(STATE_IDLE);
            if (this.greetOnLand) this.greetDelay = 34;
        } else {
            setVelocity(0.0, -vy * RESTITUTION, 0.0);
        }
    }

    private void clientTick() {
        int seq = this.dataTracker.get(IMPACT_SEQ);
        int greet = this.dataTracker.get(GREET_SEQ);
        if (this.age <= 3) { // sincronizacion inicial: no cuenta como evento
            this.lastImpactSeq = seq;
            this.lastGreetSeq = greet;
            return;
        }
        if (seq != this.lastImpactSeq) {
            this.lastImpactSeq = seq;
            this.clientImpactAge = this.age;
        }
        if (greet != this.lastGreetSeq) {
            this.lastGreetSeq = greet;
            CLIENT_GREET.accept(this);
        }
    }

    /** Clic derecho: la agarras (queda como el item Verity™ para volver a colocarla). */
    @Override
    public ActionResult interact(PlayerEntity player, Hand hand) {
        if (getBallState() == STATE_HELD) return ActionResult.PASS;
        if (!getWorld().isClient) {
            player.getInventory().offerOrDrop(new ItemStack(VerityItems.BALL));
            getWorld().playSound(null, getX(), getY(), getZ(), SoundEvents.ENTITY_ITEM_PICKUP,
                    SoundCategory.NEUTRAL, 0.6f, 1.4f);
            discard();
        }
        return ActionResult.success(getWorld().isClient);
    }

    @Override
    public boolean canHit() {
        return !isRemoved();
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean isCollidable() {
        return false;
    }

    /** Clic izquierdo: la golpeas y rebota (sin particulas). Agachado + golpe: la rompes. */
    @Override
    public boolean damage(DamageSource source, float amount) {
        if (getWorld().isClient || isRemoved()) return false;
        if (source.getAttacker() instanceof PlayerEntity p) {
            if (p.isSneaking()) {
                if (!p.isCreative()) dropStack(new ItemStack(VerityItems.BALL));
                discard();
                return true;
            }
            if (getBallState() == STATE_HELD) return false;
            this.impacts = Math.max(0, BOUNCES - 2);
            this.greetOnLand = false;
            this.greetDelay = -1;
            setBallState(STATE_FALLING);
            setVelocity(0.0, 0.38, 0.0);
            this.dataTracker.set(IMPACT_SEQ, this.dataTracker.get(IMPACT_SEQ) + 1); // cara de dolor + aplastarse
            getWorld().playSound(null, getX(), getY(), getZ(), SoundEvents.ENTITY_SLIME_SQUISH_SMALL,
                    SoundCategory.NEUTRAL, 0.9f, 1.3f);
            return true;
        }
        return false;
    }

    @Override
    public ItemStack getPickBlockStack() {
        return new ItemStack(VerityItems.BALL);
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        this.dataTracker.set(STATE, nbt.getInt("BallState"));
        this.impacts = nbt.getInt("Impacts");
        this.greetOnLand = nbt.getBoolean("GreetOnLand");
        if (nbt.containsUuid("Owner")) setOwnerUuid(nbt.getUuid("Owner"));
        // al recargar el mundo, que no se quede a medio rebote
        if (getBallState() == STATE_HELD) setBallState(STATE_FALLING);
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putInt("BallState", getBallState());
        nbt.putInt("Impacts", this.impacts);
        nbt.putBoolean("GreetOnLand", this.greetOnLand);
        UUID o = getOwnerUuid();
        if (o != null) nbt.putUuid("Owner", o);
    }

    @Override
    public Packet<ClientPlayPacketListener> createSpawnPacket() {
        return new EntitySpawnS2CPacket(this);
    }
}
