package com.verity.item;

import com.verity.VerityEntities;
import com.verity.entity.VerityBallEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** El item "Verity™" que sale al recoger la bola. Click derecho en un bloque para volver a ponerla. */
public class VerityBallItem extends Item {
    public VerityBallItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        if (!world.isClient) {
            BlockPos pos = context.getBlockPos().offset(context.getSide());
            Vec3d at = Vec3d.ofBottomCenter(pos).add(0, 0.6, 0);
            VerityBallEntity ball = VerityEntities.BALL.create(world);
            if (ball == null) return ActionResult.FAIL;
            PlayerEntity player = context.getPlayer();
            ball.refreshPositionAndAngles(at.x, at.y, at.z, 0f, 0f);
            ball.setOwnerUuid(player != null ? player.getUuid() : null);
            ball.configureAsPlaced();
            world.spawnEntity(ball);
            if (player != null && !player.isCreative()) {
                context.getStack().decrement(1);
            }
        }
        return ActionResult.success(world.isClient);
    }

    /** Click derecho en el aire con Verity™ en la mano: abre la ventana para hablarle (tambien funciona desde el inventario con la tecla V o escribiendo "verity ..." en el chat). */
    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient) VerityBallEntity.CLIENT_TALK.accept(null);
        return TypedActionResult.success(stack, world.isClient);
    }
}
