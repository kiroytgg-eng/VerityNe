package com.verity.client.render;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/** La caja de Verity (box_model.json, ya convertida del formato BBS). Coordenadas en pixeles. */
public final class BoxModel {
    private static BoxModel instance;
    private final Map<String, float[]> groups = new HashMap<>(); // por quad: 4 x (x,y,z,u,v) + nx,ny,nz = 23 floats

    public static BoxModel get() {
        if (instance == null) instance = load();
        return instance;
    }

    private static BoxModel load() {
        BoxModel m = new BoxModel();
        Identifier id = new Identifier("verity", "models_data/box_model.json");
        try (InputStreamReader r = new InputStreamReader(
                MinecraftClient.getInstance().getResourceManager().getResource(id).orElseThrow().getInputStream(), StandardCharsets.UTF_8)) {
            JsonObject groups = JsonParser.parseReader(r).getAsJsonObject().getAsJsonObject("groups");
            for (Map.Entry<String, JsonElement> e : groups.entrySet()) {
                JsonArray quads = e.getValue().getAsJsonObject().getAsJsonArray("quads");
                float[] arr = new float[quads.size() * 23];
                int o = 0;
                for (JsonElement qe : quads) {
                    JsonObject q = qe.getAsJsonObject();
                    for (JsonElement ve : q.getAsJsonArray("v")) {
                        JsonArray v = ve.getAsJsonArray();
                        for (int i = 0; i < 5; i++) arr[o++] = v.get(i).getAsFloat();
                    }
                    JsonArray n = q.getAsJsonArray("n");
                    for (int i = 0; i < 3; i++) arr[o++] = n.get(i).getAsFloat();
                }
                m.groups.put(e.getKey(), arr);
            }
        } catch (Throwable e) {
            System.err.println("[Verity] No pude cargar box_model.json: " + e);
            m.groups.clear();
        }
        return m;
    }

    public void renderGroup(String name, MatrixStack.Entry entry, VertexConsumer vc, int light) {
        float[] arr = groups.get(name);
        if (arr == null) return;
        Matrix4f pos = entry.getPositionMatrix();
        Matrix3f nrm = entry.getNormalMatrix();
        for (int q = 0; q < arr.length / 23; q++) {
            int o = q * 23;
            float nx = arr[o + 20], ny = arr[o + 21], nz = arr[o + 22];
            for (int i = 0; i < 4; i++) {
                int k = o + i * 5;
                vc.vertex(pos, arr[k], arr[k + 1], arr[k + 2]).color(1f, 1f, 1f, 1f).texture(arr[k + 3], arr[k + 4])
                        .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(nrm, nx, ny, nz).next();
            }
        }
    }
}
