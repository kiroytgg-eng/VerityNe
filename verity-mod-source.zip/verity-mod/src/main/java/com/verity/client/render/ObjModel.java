package com.verity.client.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** La esfera de Verity (model.obj) cargada como quads. */
public final class ObjModel {
    private static ObjModel instance;
    private final float[] data; // por quad: 4 vertices x (x,y,z,u,v,nx,ny,nz)
    private final int quads;

    private ObjModel(float[] data, int quads) {
        this.data = data;
        this.quads = quads;
    }

    public static ObjModel get() {
        if (instance == null) instance = load();
        return instance;
    }

    private static ObjModel load() {
        List<float[]> v = new ArrayList<>(), vt = new ArrayList<>(), vn = new ArrayList<>();
        List<int[][]> faces = new ArrayList<>();
        Identifier id = new Identifier("verity", "models_data/ball.obj");
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                MinecraftClient.getInstance().getResourceManager().getResource(id).orElseThrow().getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.trim().split("\\s+");
                if (p.length < 3) continue;
                switch (p[0]) {
                    case "v": if (p.length >= 4) v.add(new float[]{f(p[1]), f(p[2]), f(p[3])}); break;
                    case "vt": vt.add(new float[]{f(p[1]), f(p[2])}); break;
                    case "vn": if (p.length >= 4) vn.add(new float[]{f(p[1]), f(p[2]), f(p[3])}); break;
                    case "f": {
                        int n = p.length - 1;
                        if (n < 3) break;
                        int[][] face = new int[4][3];
                        for (int i = 0; i < 4; i++) {
                            String[] t = p[1 + Math.min(i, n - 1)].split("/");
                            face[i][0] = Integer.parseInt(t[0]) - 1;
                            face[i][1] = t.length > 1 && !t[1].isEmpty() ? Integer.parseInt(t[1]) - 1 : 0;
                            face[i][2] = t.length > 2 ? Integer.parseInt(t[2]) - 1 : 0;
                        }
                        faces.add(face);
                        break;
                    }
                    default:
                }
            }
        } catch (Throwable e) {
            System.err.println("[Verity] No pude cargar ball.obj: " + e);
            return new ObjModel(new float[0], 0);
        }
        float[] data = new float[faces.size() * 32];
        int o = 0;
        for (int[][] face : faces) {
            for (int[] c : face) {
                float[] pos = v.get(c[0]), uv = vt.get(c[1]), nn = vn.get(c[2]);
                data[o++] = pos[0]; data[o++] = pos[1]; data[o++] = pos[2];
                data[o++] = uv[0]; data[o++] = 1f - uv[1];
                data[o++] = nn[0]; data[o++] = nn[1]; data[o++] = nn[2];
            }
        }
        return new ObjModel(data, faces.size());
    }

    private static float f(String s) {
        return Float.parseFloat(s);
    }

    public void render(MatrixStack.Entry entry, VertexConsumer vc, int light, float r, float g, float b, float a) {
        Matrix4f pos = entry.getPositionMatrix();
        Matrix3f nrm = entry.getNormalMatrix();
        for (int i = 0; i < quads * 4; i++) {
            int k = i * 8;
            vc.vertex(pos, data[k], data[k + 1], data[k + 2]).color(r, g, b, a).texture(data[k + 3], data[k + 4])
                    .overlay(OverlayTexture.DEFAULT_UV).light(light).normal(nrm, data[k + 5], data[k + 6], data[k + 7]).next();
        }
    }
}
