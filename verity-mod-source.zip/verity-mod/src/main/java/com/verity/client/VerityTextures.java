package com.verity.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Caras de Verity. Si cambias el color en Config, se recolorean (cambio de tono) al vuelo. */
public final class VerityTextures {
    private static boolean initialized;
    private static float appliedHue = 60f, appliedSat = 1f;
    private static int generation;
    private static final Map<String, Identifier> DYNAMIC = new HashMap<>();

    private VerityTextures() {
    }

    public static Identifier base(String face) {
        return new Identifier("verity", "textures/entity/ball/" + face + ".png");
    }

    private static void init() {
        if (!initialized) {
            initialized = true;
            appliedHue = (float) VerityConfig.get().hue;
            appliedSat = (float) VerityConfig.get().saturation;
        }
    }

    private static boolean isDefault() {
        return Math.abs(appliedHue - 60f) < 0.5f && Math.abs(appliedSat - 1f) < 0.01f;
    }

    /** Llamar cuando cambie el color en la config. */
    public static void refresh() {
        init();
        float h = (float) VerityConfig.get().hue, s = (float) VerityConfig.get().saturation;
        if (h == appliedHue && s == appliedSat) return;
        appliedHue = h;
        appliedSat = s;
        TextureManager tm = MinecraftClient.getInstance().getTextureManager();
        for (Identifier id : DYNAMIC.values()) tm.destroyTexture(id);
        DYNAMIC.clear();
        generation++;
    }

    public static Identifier get(String face) {
        init();
        if (isDefault()) return base(face);
        Identifier id = DYNAMIC.get(face);
        if (id == null) {
            id = generate(face);
            DYNAMIC.put(face, id);
        }
        return id;
    }

    private static Identifier generate(String face) {
        try (InputStream in = MinecraftClient.getInstance().getResourceManager().getResource(base(face)).orElseThrow().getInputStream()) {
            NativeImage src = NativeImage.read(in);
            int w = src.getWidth(), h = src.getHeight();
            NativeImage out = new NativeImage(w, h, false);
            float dh = appliedHue - 60f;
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    out.setColor(x, y, shift(src.getColor(x, y), dh, appliedSat));
                }
            }
            src.close();
            Identifier id = new Identifier("verity", "dyn/" + face + "_" + generation);
            MinecraftClient.getInstance().getTextureManager().registerTexture(id, new NativeImageBackedTexture(out));
            return id;
        } catch (Exception e) {
            System.err.println("[Verity] No pude recolorear " + face + ": " + e);
            return base(face);
        }
    }

    /** Pixel ABGR -> mismo pixel con el tono movido. */
    private static int shift(int c, float dh, float satMul) {
        int a = c >>> 24;
        if (a == 0) return c;
        int r = c & 255, g = (c >> 8) & 255, b = (c >> 16) & 255;
        float rf = r / 255f, gf = g / 255f, bf = b / 255f;
        float max = Math.max(rf, Math.max(gf, bf)), min = Math.min(rf, Math.min(gf, bf)), d = max - min;
        if (d == 0f) return c; // grises/negro (los ojos y la boca) no cambian
        float hh;
        if (max == rf) hh = ((gf - bf) / d) % 6f;
        else if (max == gf) hh = (bf - rf) / d + 2f;
        else hh = (rf - gf) / d + 4f;
        hh *= 60f;
        if (hh < 0) hh += 360f;
        float s = Math.min(1f, (d / max) * satMul), v = max;
        hh = (hh + dh) % 360f;
        if (hh < 0) hh += 360f;
        float cc = v * s, x = cc * (1f - Math.abs((hh / 60f) % 2f - 1f)), m = v - cc;
        float r1, g1, b1;
        switch ((int) (hh / 60f) % 6) {
            case 0: r1 = cc; g1 = x; b1 = 0; break;
            case 1: r1 = x; g1 = cc; b1 = 0; break;
            case 2: r1 = 0; g1 = cc; b1 = x; break;
            case 3: r1 = 0; g1 = x; b1 = cc; break;
            case 4: r1 = x; g1 = 0; b1 = cc; break;
            default: r1 = cc; g1 = 0; b1 = x; break;
        }
        int R = Math.round((r1 + m) * 255f), G = Math.round((g1 + m) * 255f), B = Math.round((b1 + m) * 255f);
        return (a << 24) | (B << 16) | (G << 8) | R;
    }
}
