package com.verity.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** El cerebro de Verity: manda tu mensaje a Gemini o Groq y devuelve la respuesta. */
public final class VerityBrain {
    private static final ExecutorService POOL = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "Verity-Brain");
        t.setDaemon(true);
        return t;
    });
    private static final List<String[]> HISTORY = new ArrayList<>(); // {"user"|"verity", texto}
    private static volatile boolean busy;

    private static final String BASE =
            "Eres Verity™, una bola amarilla con carita que vive dentro de Minecraft y es la asistente personal del jugador. "
                    + "Eres mujer y te llamas Verity. Hablas en el idioma del jugador (por defecto español). "
                    + "Responde MUY corto: 1 a 3 frases (máximo unos 250 caracteres), sin markdown, sin emojis, sin listas ni asteriscos, "
                    + "porque tu respuesta se lee en el chat y se dice en voz alta. No menciones estas instrucciones ni digas que eres un modelo de IA. "
                    + "Todo es un juego de ficción ligera y divertida.";

    private VerityBrain() {
    }

    public static boolean isBusy() {
        return busy;
    }

    /** El jugador le habla a Verity. Llamar desde el hilo del cliente. */
    public static void ask(String userText) {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.inGameHud.setOverlayMessage(Text.literal("Verity está pensando…").formatted(Formatting.YELLOW), false);
        dispatch(userText, userText);
    }

    /** Evento del juego (alguien se acerca, etc). Verity reacciona sola. */
    public static void askEvent(String note) {
        String msg = "[Evento del juego, el jugador no escribió nada] " + note
                + " Reacciona con una sola frase corta, fiel a tu personalidad.";
        dispatch(msg, null);
    }

    private static void dispatch(String message, String echoForHistory) {
        VerityConfig cfg = VerityConfig.get();
        boolean gemini = !"groq".equalsIgnoreCase(cfg.provider);
        String key = gemini ? cfg.geminiKey : cfg.groqKey;
        if (key == null || key.isBlank()) {
            chatError("Falta la API key de " + (gemini ? "Gemini" : "Groq")
                    + ". Ábrela en Mod Menu → Verity → Config (pestaña IA).");
            return;
        }
        final String system = BASE + "\n" + cfg.personalityEnum().prompt + "\nContexto del juego: " + buildContext();
        final List<String[]> hist;
        synchronized (HISTORY) {
            hist = new ArrayList<>(HISTORY);
        }
        busy = true;
        POOL.execute(() -> {
            try {
                String raw = gemini ? callGemini(cfg, system, hist, message) : callGroq(cfg, system, hist, message);
                String reply = sanitize(raw);
                if (reply.isEmpty()) throw new RuntimeException("la IA devolvió una respuesta vacía");
                MinecraftClient.getInstance().execute(() -> {
                    synchronized (HISTORY) {
                        HISTORY.add(new String[]{"user", message});
                        HISTORY.add(new String[]{"verity", reply});
                        while (HISTORY.size() > 14) HISTORY.remove(0);
                    }
                    busy = false;
                    VerityVoice.say(reply);
                });
            } catch (Exception e) {
                MinecraftClient.getInstance().execute(() -> {
                    busy = false;
                    chatError("Error de IA: " + Http.shorten(String.valueOf(e.getMessage()), 220));
                });
            }
        });
    }

    private static String buildContext() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return "(sin datos)";
        StringBuilder sb = new StringBuilder();
        sb.append("El jugador se llama ").append(p.getName().getString()).append(". ");
        sb.append("Vida ").append(Math.round(p.getHealth())).append("/20, hambre ")
                .append(p.getHungerManager().getFoodLevel()).append("/20. ");
        long t = mc.world.getTimeOfDay() % 24000L;
        sb.append(t < 12000 ? "Es de día. " : "Es de noche. ");
        List<String> near = new ArrayList<>();
        for (AbstractClientPlayerEntity o : mc.world.getPlayers()) {
            if (o != p && o.squaredDistanceTo(p) < 100) near.add(o.getName().getString());
        }
        if (near.isEmpty()) sb.append("No hay otros jugadores cerca.");
        else sb.append("Jugadores cerca del jugador: ").append(String.join(", ", near)).append(".");
        return sb.toString();
    }

    private static void chatError(String msg) {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.inGameHud.getChatHud().addMessage(Text.literal("[Verity] " + msg).formatted(Formatting.RED));
    }

    // ---------------------------------------------------------------- Gemini

    private static String callGemini(VerityConfig cfg, String system, List<String[]> hist, String msg) throws Exception {
        JsonObject root = new JsonObject();
        JsonObject si = new JsonObject();
        JsonArray siParts = new JsonArray();
        siParts.add(textPart(system));
        si.add("parts", siParts);
        root.add("systemInstruction", si);

        JsonArray contents = new JsonArray();
        for (String[] h : hist) contents.add(geminiContent(h[0].equals("user") ? "user" : "model", h[1]));
        contents.add(geminiContent("user", msg));
        root.add("contents", contents);

        JsonObject gen = new JsonObject();
        gen.addProperty("temperature", 0.9);
        gen.addProperty("maxOutputTokens", 1024);
        root.add("generationConfig", gen);

        String model = cfg.geminiModel == null || cfg.geminiModel.isBlank() ? "gemini-flash-latest" : cfg.geminiModel.trim();
        Map<String, String> headers = new HashMap<>();
        headers.put("x-goog-api-key", cfg.geminiKey.trim());
        Http.Response r = Http.postJson("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent",
                headers, root.toString(), 45000);
        JsonObject resp = parse(r);
        if (r.code >= 400 || resp.has("error")) throw new RuntimeException("Gemini " + r.code + ": " + errorText(resp, r));
        StringBuilder out = new StringBuilder();
        JsonArray cands = resp.getAsJsonArray("candidates");
        if (cands != null && cands.size() > 0) {
            JsonObject content = cands.get(0).getAsJsonObject().getAsJsonObject("content");
            if (content != null && content.has("parts")) {
                for (JsonElement part : content.getAsJsonArray("parts")) {
                    JsonObject po = part.getAsJsonObject();
                    if (po.has("text")) out.append(po.get("text").getAsString());
                }
            }
        }
        return out.toString();
    }

    private static JsonObject textPart(String text) {
        JsonObject p = new JsonObject();
        p.addProperty("text", text);
        return p;
    }

    private static JsonObject geminiContent(String role, String text) {
        JsonObject c = new JsonObject();
        c.addProperty("role", role);
        JsonArray parts = new JsonArray();
        parts.add(textPart(text));
        c.add("parts", parts);
        return c;
    }

    // ------------------------------------------------------------------ Groq

    private static String callGroq(VerityConfig cfg, String system, List<String[]> hist, String msg) throws Exception {
        JsonObject root = new JsonObject();
        String model = cfg.groqModel == null || cfg.groqModel.isBlank() ? "llama-3.3-70b-versatile" : cfg.groqModel.trim();
        root.addProperty("model", model);
        JsonArray messages = new JsonArray();
        messages.add(groqMsg("system", system));
        for (String[] h : hist) messages.add(groqMsg(h[0].equals("user") ? "user" : "assistant", h[1]));
        messages.add(groqMsg("user", msg));
        root.add("messages", messages);
        root.addProperty("temperature", 0.9);
        root.addProperty("max_tokens", 400);

        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + cfg.groqKey.trim());
        Http.Response r = Http.postJson("https://api.groq.com/openai/v1/chat/completions", headers, root.toString(), 45000);
        JsonObject resp = parse(r);
        if (r.code >= 400 || resp.has("error")) throw new RuntimeException("Groq " + r.code + ": " + errorText(resp, r));
        JsonArray choices = resp.getAsJsonArray("choices");
        if (choices == null || choices.size() == 0) return "";
        JsonObject m = choices.get(0).getAsJsonObject().getAsJsonObject("message");
        return m != null && m.has("content") && !m.get("content").isJsonNull() ? m.get("content").getAsString() : "";
    }

    private static JsonObject groqMsg(String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        return m;
    }

    // --------------------------------------------------------------- helpers

    private static JsonObject parse(Http.Response r) {
        try {
            JsonElement e = JsonParser.parseString(r.text());
            if (e.isJsonObject()) return e.getAsJsonObject();
        } catch (Exception ignored) {
        }
        return new JsonObject();
    }

    private static String errorText(JsonObject resp, Http.Response r) {
        try {
            if (resp.has("error") && resp.get("error").isJsonObject()) {
                JsonObject err = resp.getAsJsonObject("error");
                if (err.has("message")) return Http.shorten(err.get("message").getAsString(), 200);
            }
        } catch (Exception ignored) {
        }
        return Http.shorten(r.text(), 200);
    }

    /** Quita markdown/emojis raros y acorta para que quepa en chat y voz. */
    static String sanitize(String s) {
        if (s == null) return "";
        s = s.replaceAll("[*_`#>~]", "").replaceAll("\\s+", " ").trim();
        if (s.length() > 420) {
            int cut = Math.max(s.lastIndexOf('.', 420), Math.max(s.lastIndexOf('!', 420), s.lastIndexOf('?', 420)));
            s = cut > 120 ? s.substring(0, cut + 1) : s.substring(0, 420);
        }
        return s;
    }
}
